length=int(input())
for i in range(length):
    str_input = input()
    print( "Case ",i,":\n","Echo: ",str_input,sep='')

    

    