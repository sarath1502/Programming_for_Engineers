#pragma once

class Contact {

};