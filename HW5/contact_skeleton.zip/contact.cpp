#include "contact.h"

Contact::Contact()
{
        // ADD: initialize to empty contact
}


Contact::Contact(std::string const &first_name, std::string const &last_name, std::string const &phone_number, std::string const &email)
{
        // ADD: initialize contact using constructor arguments
}